#include "stdafx.h"
#include "VerificationBox.h"

VerificationBox::VerificationBox(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

VerificationBox::~VerificationBox()
{

}
