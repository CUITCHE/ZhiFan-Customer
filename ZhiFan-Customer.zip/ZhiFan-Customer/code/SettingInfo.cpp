#include "stdafx.h"
#include "SettingInfo.h"