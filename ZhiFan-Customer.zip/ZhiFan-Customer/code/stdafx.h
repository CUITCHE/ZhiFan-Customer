#pragma once
#pragma execution_character_set("utf-8")
#include "SettingHelper.h"
#include "TerminalWidget.h"
#include <QtWidgets>
#include <QDebug>
#include <QMessageBox>
extern TerminalWidget *SingleObject;